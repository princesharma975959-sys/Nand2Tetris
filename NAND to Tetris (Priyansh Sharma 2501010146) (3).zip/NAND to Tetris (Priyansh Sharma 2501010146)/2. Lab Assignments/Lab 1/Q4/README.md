# Q4 – 16-bit Ripple-Carry Adder Using HDL

## Objective
To design and implement a 16-bit Ripple-Carry Adder using Hardware Description Language (HDL). It performs the addition of two 16-bit binary numbers.

## Files Included
1. `Add16.hdl` – Main chip that performs 16-bit binary addition.
2. `HalfAdder.hdl` – Adds the least significant bits and generates sum and carry.
3. `FullAdder.hdl` – Adds the remaining bits along with the incoming carry.

## Working
- Two 16-bit inputs, `a` and `b`, are provided.
- The Half Adder adds the first pair of bits.
- The Full Adders add the remaining bit pairs along with the carry from the previous stage.
- The carry is passed from one stage to the next.
- The final 16-bit sum is available at the output.

## Sample Operations

| Input A | Input B | Output |
|---------|---------|--------|
| 0000000000000011 | 0000000000000010 | 0000000000000101 |
| 0000000000000101 | 0000000000000011 | 0000000000001000 |
| 0000000000001010 | 0000000000000101 | 0000000000001111 |

## Conclusion
The 16-bit Ripple-Carry Adder was designed using HDL. It demonstrates binary addition by passing carry signals between consecutive adder stages.

## Testing
The chip should be tested using the provided test script in the Hardware Simulator. Simulation output screenshots should be attached after verification.