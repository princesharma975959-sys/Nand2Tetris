# 1-bit DFF-based Register (Bit Chip)

## Objective
To design and implement a 1-bit register using a D Flip-Flop (DFF) in Hardware Description Language (HDL).

## Files Included
1. `Bit.hdl` – Implements a 1-bit storage unit using a Mux and DFF.

## Working
- The chip takes one input bit (`in`) and a load signal (`load`).
- The Mux selects between the previous stored value and the new input.
- When `load = 1`, the new input value is stored.
- When `load = 0`, the previous value is retained.
- The DFF stores the selected bit on the clock cycle.
- The stored value is available at the output (`out`).

## Input and Output

| Load | Operation |
|------|-----------|
| 0 | Retains the previous value |
| 1 | Stores the new input value |

## Conclusion
The 1-bit DFF-based Register (Bit chip) was implemented using HDL. It demonstrates basic data storage and controlled writing using a D Flip-Flop.

## Testing
Run the provided test script in the Hardware Simulator and attach the simulation output screenshot after verification.