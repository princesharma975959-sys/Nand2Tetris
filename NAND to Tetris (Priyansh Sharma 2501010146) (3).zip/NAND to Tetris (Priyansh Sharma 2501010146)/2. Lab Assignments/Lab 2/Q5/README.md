# RAM512, RAM8K and RAM16K Using HDL

## Objective
To design and implement RAM512, RAM8K, and RAM16K memory chips using Hardware Description Language (HDL). These chips are built by combining smaller RAM units.

## Files Included
1. `RAM512.hdl` – Implements 512 memory locations, each storing 16-bit data.
2. `RAM8K.hdl` – Implements 8192 memory locations, each storing 16-bit data.
3. `RAM16K.hdl` – Implements 16384 memory locations, each storing 16-bit data.

## Working

### RAM512
- Contains 512 memory locations.
- Uses eight RAM64 chips.
- A 9-bit address selects one of the 512 locations.

### RAM8K
- Contains 8192 memory locations.
- Uses two RAM4K chips.
- A 13-bit address selects one of the 8192 locations.

### RAM16K
- Contains 16384 memory locations.
- Uses four RAM4K chips.
- A 14-bit address selects one of the 16384 locations.

## Memory Capacity

| RAM Chip | Memory Locations | Address Bits | Data Width |
|----------|------------------|--------------|------------|
| RAM